#pragma once

namespace enf
{
	class X final
	{
	public:
		X() = default;
		~X() = default;

		X(X&& other) = delete;
		X(const X& other) = delete;
		X& operator=(X&& other) = delete;
		X& operator=(const X& other) = delete;
	};
}